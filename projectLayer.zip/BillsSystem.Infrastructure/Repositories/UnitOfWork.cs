﻿using System;
using System.Collections.Generic;
using System.Text;
using BillsSystem.Domain.Interfaces;
using BillsSystem.Infrastructure.Data;

namespace BillsSystem.Infrastructure.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ApplicationDbContext _context;

        #region Private Field
        private ICompanyRepository? _companies;

        private IItemTypeRepository? _itemTypes;
        private ICategoryRepository? _categories;
        private IUnitRepository? _units;
        private IItemRepository? _items;
        private IClientRepository? _clients;
        private IBillRepository? _bills;
        private INotificationRepository? _notifications;
        #endregion

        public UnitOfWork(ApplicationDbContext context) => _context = context;


        #region Public Property
        public ICompanyRepository Companies => _companies ??= new CompanyRepository(_context);

        public IItemTypeRepository ItemTypes => _itemTypes ??= new ItemTypeRepository(_context);
        public ICategoryRepository Categories => _categories ??= new CategoryRepository(_context);
        public IUnitRepository Units => _units ??= new UnitRepository(_context);
        public IItemRepository Items => _items ??= new ItemRepository(_context);
        public IClientRepository Clients => _clients ??= new ClientRepository(_context);
        public IBillRepository Bills => _bills ??= new BillRepository(_context);
        public INotificationRepository Notifications => _notifications ??= new NotificationRepository(_context);
        #endregion

        public async Task<int> SaveChangesAsync() => await _context.SaveChangesAsync();
        public void Dispose() => _context.Dispose();
    }
}
