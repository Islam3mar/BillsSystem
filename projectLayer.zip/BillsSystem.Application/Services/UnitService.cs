﻿using System;
using System.Collections.Generic;
using System.Text;
using BillsSystem.Application.DTOs;
using BillsSystem.Application.Interfaces;
using BillsSystem.Domain.Entities;
using BillsSystem.Domain.Enums;
using BillsSystem.Domain.Interfaces;
using FluentValidation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BillsSystem.Application.Services
{
    public class UnitService : IUnitService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IValidator<UnitInput> _validator;
        private readonly ILogger<UnitService> _logger;
        private readonly INotificationService _notifications;

        public UnitService(IUnitOfWork unitOfWork, IValidator<UnitInput> validator, ILogger<UnitService> logger,
            INotificationService notifications)
        {
            _unitOfWork = unitOfWork;
            _validator = validator;
            _logger = logger;
            _notifications = notifications;
        }

        public async Task<IEnumerable<Unit>> GetAllUnitsAsync()
            => await _unitOfWork.Units.GetAllAsync();

        public async Task<Unit?> GetUnitByIdAsync(int id)
            => await _unitOfWork.Units.GetByIdAsync(id);

        public async Task<UnitResult> CreateUnitAsync(UnitInput input)
        {
            var result = await ValidateAsync(input, excludeId: null);
            if (result.HasErrors) return result;

            var unit = new Unit
            {
                Name = input.Name.Trim(),
                Notes = input.Notes?.Trim()
            };

            await _unitOfWork.Units.AddAsync(unit);
            try { await _unitOfWork.SaveChangesAsync(); }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Failed to create unit {Name}", input.Name);
                result.NameError = "Couldn't save. The name may already exist, or a linked record was removed";
                return result;
            }

            result.Success = true;
            await _notifications.NotifyAsync(NotificationType.Unit, NotificationAction.Created, $"Unit added: {unit.Name}", unit.Id);
            result.Unit = unit;
            return result;
        }

        public async Task<UnitResult> UpdateUnitAsync(int id, UnitInput input)
        {
            var result = await ValidateAsync(input, excludeId: id);
            if (result.HasErrors) return result;

            var unit = await _unitOfWork.Units.GetByIdAsync(id);
            if (unit == null)
            {
                result.NameError = "Unit not found";
                return result;
            }

            unit.Name = input.Name.Trim();
            unit.Notes = input.Notes?.Trim();

            try { await _unitOfWork.SaveChangesAsync(); }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Failed to update unit {Id}", id);
                result.NameError = "Couldn't save. The name may already exist, or a linked record was removed";
                return result;
            }

            result.Success = true;
            await _notifications.NotifyAsync(NotificationType.Unit, NotificationAction.Updated, $"Unit updated: {unit.Name}", unit.Id);
            result.Unit = unit;
            return result;
        }

        public async Task<(bool Success, string? Error)> DeleteUnitAsync(int id)
        {
            var unit = await _unitOfWork.Units.GetByIdAsync(id);
            if (unit == null) return (false, "Unit not found");

            _unitOfWork.Units.Delete(unit);

            try
            {
                await _unitOfWork.SaveChangesAsync();
                await _notifications.NotifyAsync(NotificationType.Unit, NotificationAction.Deleted, $"Unit deleted: {unit.Name}", null);
                return (true, null);
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Failed to delete unit {Id}", id);
                return (false, "This unit can't be deleted because it has related data linked to it");
            }
        }

        private async Task<UnitResult> ValidateAsync(UnitInput input, int? excludeId)
        {
            var result = new UnitResult();

            var validation = await _validator.ValidateAsync(input);
            if (!validation.IsValid)
            {
                foreach (var error in validation.Errors)
                {
                    if (error.PropertyName == nameof(input.Name)) result.NameError = error.ErrorMessage;
                }
                return result;
            }

            if (await _unitOfWork.Units.NameExistsAsync(input.Name.Trim(), excludeId))
                result.NameError = "UNIT NAME has already existed before";

            return result;
        }
    }
}
