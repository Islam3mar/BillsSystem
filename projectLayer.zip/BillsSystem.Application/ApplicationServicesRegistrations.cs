﻿using System;
using System.Collections.Generic;
using System.Text;
using BillsSystem.Application.Interfaces;
using BillsSystem.Application.Services;
using BillsSystem.Application.Validators;
using FluentValidation;
using Microsoft.Extensions.DependencyInjection;

namespace BillsSystem.Application
{
    public static class ApplicationServicesRegistrations
    {
        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            services.AddScoped<IAuthService, AuthService>();
            services.AddScoped<ICompanyService, CompanyService>();
            services.AddScoped<IItemTypeService, ItemTypeService>();
            services.AddScoped<ICategoryService, CategoryService>();
            services.AddScoped<IUnitService, UnitService>();
            services.AddScoped<IItemService, ItemService>();
            services.AddScoped<IClientService, ClientService>();
            services.AddScoped<IBillService, BillService>();
            services.AddScoped<ISalesReportService, SalesReportService>();
            services.AddScoped<IDashboardService, DashboardService>();
            services.AddScoped<INotificationService, NotificationService>();

            services.AddValidatorsFromAssemblyContaining<CompanyInputValidator>();

            return services;
        }
    }
}
