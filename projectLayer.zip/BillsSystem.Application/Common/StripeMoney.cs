﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BillsSystem.Application.Common
{
    internal class StripeMoney
    {
    }
}
