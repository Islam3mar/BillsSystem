﻿using BillsSystem.Application.DTOs;
using BillsSystem.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Stripe;
using Stripe.Checkout;

namespace BillsSystem.Web.Controllers
{
    [Route("webhooks/stripe")]
    [AllowAnonymous]
    public class StripeWebhookController : ControllerBase
    {
        private readonly IBillService _billService;
        private readonly StripeSettings _settings;
        private readonly ILogger<StripeWebhookController> _logger;

        public StripeWebhookController(IBillService billService, IOptions<StripeSettings> settings,
            ILogger<StripeWebhookController> logger)
        {
            _billService = billService;
            _settings = settings.Value;
            _logger = logger;
        }

        [HttpPost]
        public async Task<IActionResult> Handle()
        {
            using var reader = new StreamReader(Request.Body);
            var json = await reader.ReadToEndAsync();

            Event stripeEvent;
            try
            {
                stripeEvent = EventUtility.ConstructEvent(
                    json, Request.Headers["Stripe-Signature"], _settings.WebhookSecret,
                    throwOnApiVersionMismatch: false);
            }
            catch (StripeException ex)
            {
                _logger.LogWarning(ex, "Stripe webhook signature verification failed");
                return BadRequest();
            }

            switch (stripeEvent.Type)
            {
                case "checkout.session.completed":
                case "checkout.session.async_payment_succeeded":
                    return await HandleCheckoutPaidAsync(stripeEvent);

                case "charge.refunded":
                    return await HandleRefundAsync(stripeEvent);

                case "charge.dispute.created":
                    return await HandleDisputeAsync(stripeEvent);

                default:
                    return Ok();   // أحداث تانية مش محتاجينها
            }
        }

        private async Task<IActionResult> HandleCheckoutPaidAsync(Event stripeEvent)
        {
            // PaymentStatus مش "paid" = دفع لسه معلّق (async)، وهيجي async_payment_succeeded بعدين
            if (stripeEvent.Data.Object is not Session session || session.PaymentStatus != "paid")
                return Ok();

            if (!int.TryParse(session.Metadata?.GetValueOrDefault("billId"), out var billId))
                return Ok();

            var amount = (session.AmountTotal ?? 0) / 100m;
            var (success, error) = await _billService.ConfirmStripePaymentAsync(
                session.Id, session.PaymentIntentId, amount, billId);

            if (!success)
            {
                _logger.LogError("Failed to confirm Stripe payment for session {SessionId}: {Error}", session.Id, error);
                return StatusCode(StatusCodes.Status500InternalServerError);   // Stripe هتعيد المحاولة
            }

            return Ok();
        }

        private async Task<IActionResult> HandleRefundAsync(Event stripeEvent)
        {
            if (stripeEvent.Data.Object is not Charge charge || string.IsNullOrEmpty(charge.PaymentIntentId))
                return Ok();

            var (success, error) = await _billService.HandleStripeRefundAsync(
                charge.PaymentIntentId, charge.AmountRefunded / 100m);

            if (!success)
            {
                _logger.LogError("Failed to apply Stripe refund for payment intent {PaymentIntentId}: {Error}", charge.PaymentIntentId, error);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

            return Ok();
        }

        private async Task<IActionResult> HandleDisputeAsync(Event stripeEvent)
        {
            if (stripeEvent.Data.Object is not Dispute dispute) return Ok();

            var (success, error) = await _billService.HandleStripeDisputeAsync(
                dispute.PaymentIntentId, dispute.Amount / 100m, dispute.Reason);

            if (!success)
            {
                _logger.LogError("Failed to record Stripe dispute {DisputeId}: {Error}", dispute.Id, error);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

            return Ok();
        }
    }
}